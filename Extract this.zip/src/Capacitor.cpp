#include "Arduino.h"
// Simple Capacitance Meter for ESP32
// Author: ChatGPT
// Measures capacitance and prints result in nanoFarads (nF)

const int OUT_PIN = 26; // GPIO to charge capacitor
const int IN_PIN = 34;  // GPIO to read voltage across capacitor (must be ADC-capable)

const float R_PULLUP = 10000.0; // 10k ohm resistor

void setup() {
  Serial.begin(115200);
  
  pinMode(OUT_PIN, OUTPUT);
  digitalWrite(OUT_PIN, LOW);

  analogReadResolution(12); // 12 bits = 0 to 4095
}

void loop() {
  float capacitance_nF = measureCapacitance();
  
  Serial.print("Capacitance: ");
  Serial.print(capacitance_nF, 2); // 2 decimal places
  Serial.println(" nF");

  delay(1000); // Measure every second
}

float measureCapacitance() {
  // Discharge capacitor
  pinMode(IN_PIN, OUTPUT);
  digitalWrite(IN_PIN, LOW);
  delay(10);
  
  pinMode(IN_PIN, INPUT);
  digitalWrite(OUT_PIN, HIGH); // Start charging

  unsigned long startTime = micros();
  
  // Wait until capacitor voltage reaches about 63% of Vcc
  while (analogRead(IN_PIN) < 0.63 * 4095) {
    if (micros() - startTime > 1000000) {
      // Timeout after 1 second to avoid locking up if no capacitor
      digitalWrite(OUT_PIN, LOW);
      return -1.0;
    }
  }
  
  unsigned long elapsedTime = micros() - startTime;
  
  digitalWrite(OUT_PIN, LOW); // Stop charging

  float timeSec = elapsedTime / 1000000.0; // Convert microseconds to seconds
  
  float capacitanceFarads = timeSec / R_PULLUP;
  
  float capacitance_nF = capacitanceFarads * 1e9; // Convert to nanoFarads
  
  return capacitance_nF;
}
