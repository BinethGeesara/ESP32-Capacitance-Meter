#include "Arduino.h"
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels

#define OSC_INPUT_PIN  4   // Connect your oscillator output here
#define R_OHMS         1400000  // 1.399MΩ
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

void setup() {
  Serial.begin(115200);
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { // Address 0x3D for 128x64
    Serial.println(F("SSD1306 allocation failed"));
    for(;;);
  }
  delay(2000);
  display.clearDisplay();

  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0, 10);
  // Display static text
  display.println("Hello, world!");
  display.display(); 
  pinMode(OSC_INPUT_PIN, INPUT);
}

void loop() {
  // Measure one cycle (high + low)
  uint32_t highTime = pulseIn(OSC_INPUT_PIN, HIGH);
  uint32_t lowTime = pulseIn(OSC_INPUT_PIN, LOW);

  if (highTime == 0 || lowTime == 0) {
    Serial.println("No signal detected!");
    display.clearDisplay();
    display.setCursor(0, 10);
    display.println("No signal detected!");
    display.display();
    delay(500);
    return;
  }

  // Total period in microseconds
  float period_us = highTime + lowTime;
  float frequency = 1e6 / period_us;  // Convert period to frequency

  // Calculate capacitance
  float capacitance = 1.0 / (1.1 * R_OHMS * frequency); // in Farads
  capacitance *= 1e12;  // Convert to pF

  // Clear the display
  display.clearDisplay();
  display.setCursor(0, 10);

  // Decide unit and display on OLED
  if (capacitance >= 1000.0) {
    Serial.print("Capacitance: ");
    Serial.print(capacitance / 1000.0);  // Convert to nF
    Serial.println(" nF");

    display.print("Capacitance: ");
    display.print(capacitance / 1000.0);  // Convert to nF
    display.println(" nF");
  } else {
    Serial.print("Capacitance: ");
    Serial.print(capacitance);
    Serial.println(" pF");

    display.print("Capacitance: ");
    display.print(capacitance);
    display.println(" pF");
  }

  // Update the OLED display
  display.display();

  delay(500);
}
